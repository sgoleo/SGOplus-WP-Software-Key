<?php
/**
 * Plugin Name: SGOplus Software Key
 * Description: Modernized software license management system with secure REST API and React-based dashboard.
 * Version: 1.0.7
 * Author: SGOplus
 * Author URI: https://sgoplus.one
 * License: GPLv2 or later
 * Text Domain: sgoplus-software-key
 * Requires at least: 6.5
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define constants
define( 'SGOPLUS_SWK_VERSION', '1.0.7' );
define( 'SGOPLUS_SWK_PATH', plugin_dir_path( __FILE__ ) );
define( 'SGOPLUS_SWK_URL', plugin_dir_url( __FILE__ ) );

/**
 * Core Classes Loading
 */
require_once SGOPLUS_SWK_PATH . 'includes/class-db-schema.php';
require_once SGOPLUS_SWK_PATH . 'includes/libraries/class-wp-async-request.php';
require_once SGOPLUS_SWK_PATH . 'includes/libraries/class-wp-background-process.php';
require_once SGOPLUS_SWK_PATH . 'includes/class-migration-worker.php';
require_once SGOPLUS_SWK_PATH . 'includes/class-migration-engine.php';
require_once SGOPLUS_SWK_PATH . 'includes/class-rest-api.php';
require_once SGOPLUS_SWK_PATH . 'includes/class-admin-dashboard.php';

/**
 * Activation Logic
 */
register_activation_hook( __FILE__, array( 'SGOplus\\SoftwareKey\\DB_Schema', 'install' ) );

/**
 * Initialize Components
 */
add_action( 'plugins_loaded', function() {
	// Initialize Migration Engine
	if ( class_exists( 'SGOplus\\SoftwareKey\\Migration_Engine' ) ) {
		new \SGOplus\SoftwareKey\Migration_Engine();
	}

	// Initialize REST API
	if ( class_exists( 'SGOplus\\SoftwareKey\\REST_API' ) ) {
		new \SGOplus\SoftwareKey\REST_API();
	}
} );

/**
 * Admin Menu - Procedural approach for maximum compatibility with WP 6.9
 */
add_action( 'admin_menu', function() {
	$capability = 'manage_options';
	$slug = 'sgoplus-swk-dashboard';

	// 1. Main Menu
	add_menu_page(
		'SGOplus Software Key',
		'Software Key+',
		$capability,
		$slug,
		'sgoplus_swk_render_dashboard',
		'dashicons-shield-lock',
		26
	);

	// 2. Submenus
	add_submenu_page( $slug, 'Licenses', 'Licenses', $capability, $slug, 'sgoplus_swk_render_dashboard' );
	add_submenu_page( $slug, 'Add New', 'Add New', $capability, $slug . '-add', 'sgoplus_swk_render_dashboard' );
	add_submenu_page( $slug, 'Logs', 'Activation Logs', $capability, $slug . '-logs', 'sgoplus_swk_render_dashboard' );
	add_submenu_page( $slug, 'Settings', 'Settings', $capability, $slug . '-settings', 'sgoplus_swk_render_dashboard' );
	add_submenu_page( $slug, 'Guide', 'Guide', $capability, $slug . '-guide', 'sgoplus_swk_render_dashboard' );
}, 99 );

/**
 * Render Dashboard
 */
function sgoplus_swk_render_dashboard() {
	echo '<div id="sgoplus-swk-admin-root"></div>';
	
	// Enqueue assets manually here to be safe
	$dashboard = new \SGOplus\SoftwareKey\Admin_Dashboard();
	$dashboard->enqueue_assets( 'toplevel_page_sgoplus-swk-dashboard' );
}

/**
 * Ensure assets are enqueued
 */
add_action( 'admin_enqueue_scripts', function( $hook ) {
	if ( strpos( $hook, 'sgoplus-swk-dashboard' ) !== false ) {
		$dashboard = new \SGOplus\SoftwareKey\Admin_Dashboard();
		$dashboard->enqueue_assets( $hook );
	}
}, 99 );
