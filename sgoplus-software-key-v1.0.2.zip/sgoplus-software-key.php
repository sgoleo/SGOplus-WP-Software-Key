<?php
/**
 * Plugin Name: SGOplus Software Key
 * Description: Modernized software license management system with secure REST API and React-based dashboard.
 * Version: 1.0.0
 * Author: SGOplus
 * Author URI: https://sgoplus.one
 * License: GPLv2 or later
 * Text Domain: sgoplus-software-key
 * Requires at least: 6.5
 * Requires PHP: 7.4
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define constants
define( 'SGOPLUS_SWK_VERSION', '1.0.1' );
define( 'SGOPLUS_SWK_PATH', plugin_dir_path( __FILE__ ) );
define( 'SGOPLUS_SWK_URL', plugin_dir_url( __FILE__ ) );

/**
 * Manual Class Loading (Ensures absolute stability during activation)
 */
require_once SGOPLUS_SWK_PATH . 'includes/class-db-schema.php';
require_once SGOPLUS_SWK_PATH . 'includes/libraries/class-wp-async-request.php';
require_once SGOPLUS_SWK_PATH . 'includes/libraries/class-wp-background-process.php';
require_once SGOPLUS_SWK_PATH . 'includes/class-migration-worker.php';
require_once SGOPLUS_SWK_PATH . 'includes/class-migration-engine.php';
require_once SGOPLUS_SWK_PATH . 'includes/class-rest-api.php';
require_once SGOPLUS_SWK_PATH . 'includes/class-admin-dashboard.php';

/**
 * Activation Logic
 */
register_activation_hook( __FILE__, array( 'SGOplus\\SoftwareKey\\DB_Schema', 'install' ) );

/**
 * Initialize Plugin
 */
function sgoplus_swk_init_plugin() {
	// Initialize Migration Engine
	if ( is_admin() ) {
		new SGOplus\SoftwareKey\Migration_Engine();
	}

	// Initialize REST API
	new SGOplus\SoftwareKey\REST_API();

	// Initialize Admin Dashboard
	if ( is_admin() ) {
		new SGOplus\SoftwareKey\Admin_Dashboard();
	}
}
add_action( 'plugins_loaded', 'sgoplus_swk_init_plugin' );
