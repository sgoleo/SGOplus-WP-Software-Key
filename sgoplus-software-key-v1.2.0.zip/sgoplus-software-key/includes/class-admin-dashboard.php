<?php
/**
 * Admin Dashboard Class
 *
 * @package SGOplus\SoftwareKey
 */

namespace SGOplus\SoftwareKey;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Admin_Dashboard
 * Handles the React-based admin interface asset enqueueing.
 */
class Admin_Dashboard {

	/**
	 * Enqueue Assets
	 *
	 * @param string $hook Current admin page hook suffix.
	 */
	public function enqueue_assets( $hook ) {
		/*
		 * WordPress generates submenu hook suffixes in the format:
		 *   {sanitized-parent-title}_page_{submenu-slug}
		 * For "Software Key+" the sanitized title slug is "software-key".
		 *
		 * The top-level page hook is always:
		 *   toplevel_page_{top-level-slug}
		 */
		$allowed_hooks = array(
			'toplevel_page_sgoplus-swk-dashboard',
			'software-key_page_sgoplus-swk-dashboard-add',
			'software-key_page_sgoplus-swk-dashboard-logs',
			'software-key_page_sgoplus-swk-dashboard-settings',
			'software-key_page_sgoplus-swk-dashboard-guide',
		);

		if ( ! in_array( $hook, $allowed_hooks, true ) ) {
			return;
		}

		$dist_path     = SGOPLUS_SWK_PATH . 'assets/dist/';
		$dist_url      = SGOPLUS_SWK_URL . 'assets/dist/';
		$manifest_file = $dist_path . '.vite/manifest.json';

		if ( ! file_exists( $manifest_file ) ) {
			add_action(
				'admin_notices',
				static function () {
					echo '<div class="notice notice-warning"><p>' .
						esc_html__( 'SGOplus Software Key: Frontend assets not built. Run ', 'sgoplus-software-key' ) .
						'<code>npm run build</code>.</p></div>';
				}
			);
			return;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$manifest = json_decode( file_get_contents( $manifest_file ), true );

		if ( ! is_array( $manifest ) || ! isset( $manifest['src/main.tsx'] ) ) {
			return;
		}

		$entry = $manifest['src/main.tsx'];

		// Enqueue JS (module type required for Vite-built ES modules).
		wp_enqueue_script(
			'sgoplus-swk-admin',
			$dist_url . $entry['file'],
			array(),
			SGOPLUS_SWK_VERSION,
			true
		);

		// Make it a proper ES module so Vite chunks load correctly.
		add_filter(
			'script_loader_tag',
			static function ( $tag, $handle ) {
				if ( 'sgoplus-swk-admin' !== $handle ) {
					return $tag;
				}
				return str_replace( ' src=', ' type="module" src=', $tag );
			},
			10,
			2
		);

		// Enqueue CSS.
		if ( ! empty( $entry['css'] ) ) {
			foreach ( $entry['css'] as $css_file ) {
				wp_enqueue_style(
					'sgoplus-swk-admin-' . md5( $css_file ),
					$dist_url . $css_file,
					array(),
					SGOPLUS_SWK_VERSION
				);
			}
		}

		// Provide REST API root + nonce to the React app.
		wp_localize_script(
			'sgoplus-swk-admin',
			'sgoplusSwkData',
			array(
				'root'  => esc_url_raw( rest_url( 'sgoplus-swk/v1' ) ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
			)
		);
	}
}
