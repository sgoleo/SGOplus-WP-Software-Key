<?php
/**
 * Admin Dashboard Class
 *
 * @package SGOplus\SoftwareKey
 */

namespace SGOplus\SoftwareKey;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Admin_Dashboard
 * Handles the React-based admin interface asset enqueueing.
 */
class Admin_Dashboard {

	/**
	 * Constructor — registers the enqueue hook at the correct time.
	 */
	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Enqueue Assets
	 *
	 * Called by admin_enqueue_scripts with the current page hook suffix.
	 *
	 * @param string $hook_suffix Current admin page hook suffix provided by WP.
	 */
	public function enqueue_assets( $hook_suffix ) {
		// Load only on our plugin pages (match by slug substring).
		if ( strpos( $hook_suffix, 'sgoplus-swk-dashboard' ) === false ) {
			return;
		}

		$dist_path     = SGOPLUS_SWK_PATH . 'assets/dist/';
		$dist_url      = SGOPLUS_SWK_URL . 'assets/dist/';
		$manifest_file = $dist_path . '.vite/manifest.json';

		if ( ! file_exists( $manifest_file ) ) {
			add_action(
				'admin_notices',
				static function () {
					echo '<div class="notice notice-warning"><p>' .
						esc_html__( 'SGOplus Software Key: Frontend assets not built. Run ', 'sgoplus-software-key' ) .
						'<code>npm run build</code>.</p></div>';
				}
			);
			return;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$manifest = json_decode( file_get_contents( $manifest_file ), true );

		if ( ! is_array( $manifest ) ) {
			return;
		}

		// ── JS: find the entry point by isEntry flag ──────────────────────────
		$entry = null;
		foreach ( $manifest as $item ) {
			if ( is_array( $item ) && ! empty( $item['isEntry'] ) && ! empty( $item['file'] ) ) {
				$entry = $item;
				break;
			}
		}

		if ( null === $entry ) {
			return;
		}

		// Enqueue JS — IIFE format, no type="module" needed.
		wp_enqueue_script(
			'sgoplus-swk-admin',
			$dist_url . $entry['file'],
			array(),
			SGOPLUS_SWK_VERSION,
			true  // Load in footer.
		);

		// ── CSS: may be in entry['css'] array OR as a separate manifest key ───
		$css_files = array();

		// Check entry-level css array (ESM builds).
		if ( ! empty( $entry['css'] ) && is_array( $entry['css'] ) ) {
			$css_files = $entry['css'];
		}

		// Check top-level manifest keys for standalone CSS entries (IIFE builds).
		foreach ( $manifest as $key => $item ) {
			if ( is_array( $item ) && ! empty( $item['file'] ) && substr( $item['file'], -4 ) === '.css' ) {
				$css_files[] = $item['file'];
			}
		}

		$css_files = array_unique( $css_files );

		foreach ( $css_files as $css_file ) {
			wp_enqueue_style(
				'sgoplus-swk-admin-css',
				$dist_url . $css_file,
				array(),
				SGOPLUS_SWK_VERSION
			);
		}

		// ── Provide REST API data to React ─────────────────────────────────────
		wp_localize_script(
			'sgoplus-swk-admin',
			'sgoplusSwkData',
			array(
				'root'  => esc_url_raw( rest_url( 'sgoplus-swk/v1' ) ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
			)
		);
	}
}
